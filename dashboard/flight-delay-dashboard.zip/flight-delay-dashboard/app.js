const DATA_PATH = 'data/flight_delay_dataset_50_cleaned.xlsx';
const $ = id => document.getElementById(id);
const palette = ['#19376d','#576cbc','#f28c28','#2a9d8f','#e76f51','#8d99ae','#6a4c93','#e9c46a','#264653','#a8dadc'];
let allRows = [], keys = [], map = {}, charts = {};

const norm = s => String(s).toLowerCase().replace(/[^a-z0-9]/g, '');
const causeDefs = [['Carrier', /carrier/], ['Weather', /weather/], ['NAS', /nas/], ['Security', /security/], ['Late aircraft', /lateaircraft/]];

function find(pats, exclude) {
  for (const p of pats) {
    const k = keys.find(k => p.test(norm(k)) && !(exclude && exclude.test(norm(k))));
    if (k) return k;
  }
  return '';
}
function detect() {
  const noCause = /carrierdelay|weatherdelay|nasdelay|securitydelay|lateaircraft/;
  map = {
    airline: find([/^(airline|airlinename|carrier|carriername|opcarrier|uniquecarrier)$/, /airline/, /carrier/], noCause),
    origin: find([/^(origin|originairport|origincode|departureairport)$/, /origin/]),
    dest: find([/^(dest|destination|destinationairport|destcode|arrivalairport)$/, /dest/]),
    distance: find([/distance/]),
    delayMin: find([/^(arrdelay|arrivaldelay|arrdelayminutes|arrivaldelayminutes|delayminutes|totaldelay|delay)$/, /arr.*delay/, /dep.*delay/, /delay.*min/], noCause),
    flag: find([/delayed15/, /^isdelayed$/, /^delayed/], /cause/),
    date: find([/date/]),
    hour: find([/^(hour|dephour|departurehour|scheduledhour)$/, /hour/]),
    weatherCat: find([/weathercondition/, /weathercat/, /^weather$/, /condition/])
  };
}
const num = v => { const n = parseFloat(v); return isNaN(n) ? null : n; };
function isDelayed(r) {
  if (map.flag) { const v = r[map.flag]; return v === true || v === 1 || /^(1|yes|y|true)$/i.test(String(v)); }
  if (map.delayMin) { const n = num(r[map.delayMin]); return n !== null && n >= 15; }
  return false;
}
function toDate(v) {
  if (v instanceof Date) return v;
  if (typeof v === 'number') return new Date(Math.round((v - 25569) * 86400000));
  const d = new Date(v); return isNaN(d) ? null : d;
}
function causeCols() {
  return causeDefs.map(([label, re]) => {
    const k = keys.find(k => re.test(norm(k)) && /delay|cause/.test(norm(k)));
    return k ? [label, k] : null;
  }).filter(Boolean);
}
function group(rows, keyFn) {
  const m = new Map();
  for (const r of rows) {
    const k = keyFn(r); if (k === null || k === undefined || k === '') continue;
    const g = m.get(k) || { n: 0, d: 0, sum: 0, cnt: 0 };
    g.n++; if (isDelayed(r)) g.d++;
    const dm = map.delayMin ? num(r[map.delayMin]) : null;
    if (dm !== null) { g.sum += dm; g.cnt++; }
    m.set(k, g);
  }
  return m;
}
const rate = g => g.n ? +(100 * g.d / g.n).toFixed(1) : 0;

function chart(id, title, config) {
  let card = $('c_' + id);
  if (!card) {
    card = document.createElement('div'); card.className = 'card'; card.id = 'c_' + id;
    card.innerHTML = `<h3>${title}</h3><canvas></canvas>`; $('charts').appendChild(card);
  }
  if (charts[id]) charts[id].destroy();
  charts[id] = new Chart(card.querySelector('canvas'), config);
}
function removeChart(id) { if (charts[id]) { charts[id].destroy(); delete charts[id]; } const c = $('c_' + id); if (c) c.remove(); }
function bar(id, title, g, top, horizontal = true) {
  if (!g || !g.size) return removeChart(id);
  const arr = [...g.entries()].filter(([, v]) => v.n >= 1).sort((a, b) => b[1].n - a[1].n).slice(0, top)
    .sort((a, b) => rate(b[1]) - rate(a[1]));
  chart(id, title, { type: 'bar', data: { labels: arr.map(a => a[0]), datasets: [{ label: 'Delay rate (%)', data: arr.map(a => rate(a[1])), backgroundColor: '#576cbc' }] },
    options: { indexAxis: horizontal ? 'y' : 'x', plugins: { legend: { display: false } }, scales: { [horizontal ? 'x' : 'y']: { title: { display: true, text: '% flights delayed 15+ min' } } } } });
}

function render() {
  const fa = $('fAirline').value, fo = $('fOrigin').value;
  const rows = allRows.filter(r => (!fa || String(r[map.airline]) === fa) && (!fo || String(r[map.origin]) === fo));
  const delayed = rows.filter(isDelayed).length;
  const dm = map.delayMin ? rows.map(r => num(r[map.delayMin])).filter(v => v !== null) : [];
  const ds = map.distance ? rows.map(r => num(r[map.distance])).filter(v => v !== null) : [];
  const avg = a => a.length ? a.reduce((x, y) => x + y, 0) / a.length : null;
  const kp = [['Flights', rows.length.toLocaleString()], ['Delayed (15+ min)', delayed.toLocaleString()],
    ['Delay rate', rows.length ? (100 * delayed / rows.length).toFixed(1) + '%' : '–']];
  if (dm.length) kp.push(['Avg delay (min)', avg(dm).toFixed(1)]);
  if (ds.length) kp.push(['Avg distance (mi)', Math.round(avg(ds)).toLocaleString()]);
  $('kpis').innerHTML = kp.map(([l, v]) => `<div class="kpi"><b>${v}</b><span>${l}</span></div>`).join('');

  map.airline ? bar('airline', 'Delay rate by airline', group(rows, r => r[map.airline]), 12) : removeChart('airline');
  map.origin ? bar('origin', 'Delay rate by origin airport (top 12 busiest)', group(rows, r => r[map.origin]), 12) : removeChart('origin');
  map.weatherCat ? bar('weather', 'Delay rate by weather condition', group(rows, r => r[map.weatherCat]), 10, false) : removeChart('weather');

  const cc = causeCols();
  if (cc.length) {
    const tot = cc.map(([, k]) => rows.reduce((s, r) => s + (num(r[k]) || 0), 0));
    chart('causes', 'Delay minutes by cause', { type: 'doughnut', data: { labels: cc.map(c => c[0]), datasets: [{ data: tot, backgroundColor: palette }] } });
  } else removeChart('causes');

  if (map.date) {
    const g = group(rows, r => { const d = toDate(r[map.date]); return d ? d.getUTCFullYear() + '-' + String(d.getUTCMonth() + 1).padStart(2, '0') : null; });
    const arr = [...g.entries()].sort((a, b) => a[0].localeCompare(b[0]));
    arr.length ? chart('time', 'Delay rate over time (by month)', { type: 'line', data: { labels: arr.map(a => a[0]), datasets: [{ label: 'Delay rate (%)', data: arr.map(a => rate(a[1])), borderColor: '#f28c28', tension: .3 }] } }) : removeChart('time');
  } else removeChart('time');

  if (map.hour) {
    const g = group(rows, r => num(r[map.hour]));
    const arr = [...g.entries()].sort((a, b) => a[0] - b[0]);
    arr.length ? chart('hour', 'Delay rate by hour of day', { type: 'bar', data: { labels: arr.map(a => a[0]), datasets: [{ label: 'Delay rate (%)', data: arr.map(a => rate(a[1])), backgroundColor: '#19376d' }] }, options: { plugins: { legend: { display: false } } } }) : removeChart('hour');
  } else removeChart('hour');

  if (map.distance && map.delayMin) {
    const pts = rows.map(r => ({ x: num(r[map.distance]), y: num(r[map.delayMin]) })).filter(p => p.x !== null && p.y !== null);
    pts.length ? chart('scatter', 'Distance vs delay', { type: 'scatter', data: { datasets: [{ label: 'Flights', data: pts, backgroundColor: 'rgba(87,108,188,.6)' }] },
      options: { scales: { x: { title: { display: true, text: 'Distance (miles)' } }, y: { title: { display: true, text: 'Delay (min)' } } }, plugins: { legend: { display: false } } } }) : removeChart('scatter');
  } else removeChart('scatter');
}

function fillFilters() {
  for (const [id, col] of [['fAirline', map.airline], ['fOrigin', map.origin]]) {
    const sel = $(id); sel.innerHTML = '<option value="">All</option>';
    if (!col) continue;
    [...new Set(allRows.map(r => String(r[col])))].sort().forEach(v => sel.add(new Option(v, v)));
  }
}
function fillMapping() {
  const labels = { airline: 'Airline', origin: 'Origin', dest: 'Destination', distance: 'Distance', delayMin: 'Delay minutes', flag: 'Delayed flag (0/1)', date: 'Date', hour: 'Hour', weatherCat: 'Weather category' };
  $('mapBody').innerHTML = Object.keys(labels).map(k =>
    `<label>${labels[k]}<select data-k="${k}"><option value="">(none)</option>${keys.map(c => `<option ${c === map[k] ? 'selected' : ''}>${c}</option>`).join('')}</select></label>`).join('');
  $('mapBody').querySelectorAll('select').forEach(s => s.onchange = () => { map[s.dataset.k] = s.value; fillFilters(); render(); });
}
function load(wb, name) {
  const sheet = wb.SheetNames.find(n => /^cleaned$/i.test(n)) || wb.SheetNames[0];
  allRows = XLSX.utils.sheet_to_json(wb.Sheets[sheet], { defval: null, cellDates: true });
  keys = allRows.length ? Object.keys(allRows[0]) : [];
  detect(); fillFilters(); fillMapping(); render();
  $('status').innerHTML = `Loaded <b>${allRows.length}</b> rows from <b>${name}</b> (sheet “${sheet}”).`;
}
async function init() {
  try {
    const res = await fetch(DATA_PATH); if (!res.ok) throw new Error(res.status);
    load(XLSX.read(await res.arrayBuffer(), { type: 'array', cellDates: true }), DATA_PATH);
  } catch (e) {
    $('status').innerHTML = `<span class="err">Could not load <code>${DATA_PATH}</code>.</span> Put the Excel file in the <code>data/</code> folder, or choose a file with “Use another file”. (Opening index.html straight from disk blocks loading; use GitHub Pages or <code>python -m http.server</code>.)`;
  }
}
$('file').onchange = async e => { const f = e.target.files[0]; if (f) load(XLSX.read(await f.arrayBuffer(), { type: 'array', cellDates: true }), f.name); };
$('fAirline').onchange = $('fOrigin').onchange = render;
init();
