# Flight Delay & Airline Performance Dashboard

Interactive dashboard for the US DOT / BTS flight-delay dataset (delay causes, airline performance, airport congestion, weather).

## Run locally
1. Copy `flight_delay_dataset_50_cleaned.xlsx` into the `data/` folder.
2. Start a local server in this folder: `python -m http.server 8000`
3. Open http://localhost:8000

You can also open the page and use **Use another file** to load any .xlsx/.csv without a server.

## Publish on GitHub Pages
1. Create a new GitHub repo and upload everything in this folder (including `data/`).
2. Repo **Settings → Pages → Deploy from a branch → `main` / root**.
3. Your dashboard will be live at `https://<username>.github.io/<repo>/`.

## Notes
- Columns are auto-detected (airline, origin, distance, delay minutes, `delayed_15plus`, delay causes, date, hour, weather). If a chart looks wrong, fix it under **Column mapping** on the page.
- Uses the `Cleaned` sheet by default.
- Libraries load from a CDN (Chart.js, SheetJS), so an internet connection is required.
