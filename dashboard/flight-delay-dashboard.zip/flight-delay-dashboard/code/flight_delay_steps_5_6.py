import pandas as pd

PATH = 'data/flight_delay_dataset_50_cleaned.xlsx'  # change to /content/dataset/... in Colab

# Step 5: Load and explore
df = pd.read_excel(PATH, sheet_name='Cleaned')
print(df.head())
print(df.shape)
print(df.info())
print(df.describe())

# Step 6: Check and verify
ml = pd.read_excel(PATH, sheet_name='ML_Ready')
print('Cleaned shape:', df.shape, '| ML_Ready shape:', ml.shape)
print('Missing (Cleaned):\n', df.isnull().sum())
print('Missing (ML_Ready):\n', ml.isnull().sum())
print('Duplicate rows:', df.duplicated().sum())
print('Negative distances:', (df['distance_miles'] < 0).sum())
print('Origin same as destination:', (df['origin'] == df['destination']).sum())
